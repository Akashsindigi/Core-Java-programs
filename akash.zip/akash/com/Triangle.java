package akash.com;

public class Triangle {

	public static void main(String[] args) 
	{
		double l,b,triangle;
		l = 10;
		b = 5;
		triangle = l*b/2;
		System.out.println("the area of triangle of length "+l+" and breadth "+b+" is "+triangle);
	
	}

}
