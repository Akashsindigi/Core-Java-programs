package akash.com;

public class LoopingSum {

	public static void main(String[] args) {
		int i, sum=0;
		i=0;
		while(i<=10) {
			sum=sum+i;
			i=i+2;
			System.out.println("sum = "+sum);
		}

	}

}
