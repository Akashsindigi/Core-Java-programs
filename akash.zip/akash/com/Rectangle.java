package akash.com;

public class Rectangle {

	public static void main(String[] args) {
		int l,b,area;
		l = 45;
		b = 20;
		area = l*b;
		System.out.println("the area of rectangle of length "+l+" and breadth "+b+" is "+area);			

	}

}
