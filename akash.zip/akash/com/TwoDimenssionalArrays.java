package akash.com;

import java.util.Scanner;

public class TwoDimenssionalArrays {

	public static void main(String[] args) {
		
		int b[][]=new int[4][4]; 
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter 4x4 matrix");
		for(int r=0;r<4;r++) {
			for(int c=0;c<4;c++) {
				b[r][c] = sc.nextInt();
			}
		}
		
		System.out.println("Entered Matrix is");
		for(int r=0;r<4;r++) {
			for(int c=0;c<4;c++) {
				System.out.print(b[r][c] +" ");
			}
			
			System.out.println();
		}

	}

}
