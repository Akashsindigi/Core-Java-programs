package akash.com;

import java.util.Scanner;

public class BankingProgram {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Banking program");
		System.out.println("1.Amount to be deposited"); 
		System.out.println("2.Amount to be withdrawn");
		System.out.println("3.display the balance");
		System.out.println("Choose the type of conversion ");
		float amount=10000;
		float deposite_amount,withdraw_amount,balance;
		int choice;
		choice=sc.nextInt();
		switch(choice) {
		case 1:
		System.out.println("Enter the amount to be deposited");
		deposite_amount=sc.nextFloat();
		balance=amount+deposite_amount;
		System.out.println("The balance amount is "+balance);
		break;
		case 2:
			System.out.println("Enter the amount to be withdrawn");
		    withdraw_amount = sc.nextFloat();
		    if(withdraw_amount<amount) {
		    balance=amount-withdraw_amount;
		System.out.println("The balance amount is "+balance);
		    }
		else {
			System.out.println("insufficent balance");
		}
		break;
            default:
			System.out.println("invalid input");
	}

	}
	}
