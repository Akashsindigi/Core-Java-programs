package akash.com;

import java.util.Scanner;

public class FactorialLooping {

	public static void main(String[] args) {
		int i,num,factorial=1;
		Scanner input= new Scanner(System.in);
		System.out.println("enter the num :");
		num= input.nextInt();
		
		i=num;
		while(i>=1) {
			factorial=factorial*i;
			i=i-1;
		}
		System.out.println("factorial of the num is "+factorial);

	}

}
