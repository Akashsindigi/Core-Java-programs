package akash.com;

import java.util.Scanner;

public class StudentDetails {

	public static void main(String[] args) {
	int Marks;
	Scanner sc= new Scanner(System.in);
	System.out.println("enter student Marks");
	Marks=sc.nextInt();
	if(Marks>= 90 && Marks<=100) {
		System.out.println("A Grade");
	}
	else if(Marks>=70 && Marks<=89) {
	System.out.println("B Grade");
	}
	else if(Marks>=35 && Marks<=69) {
		System.out.println("C Grade");
	}
	else if(Marks>100) {
		System.out.println("invalid");
	}
	else {
		System.out.println("fail");
	}
	
	}

}
