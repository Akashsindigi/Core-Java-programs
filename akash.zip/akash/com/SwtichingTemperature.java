package akash.com;

import java.util.Scanner;

public class SwtichingTemperature {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Temperature conversion");
		System.out.println("1.Celcius to Fahrenheit conversion"); 
		System.out.println("2.Fahrenheit to Celcius conversion ");
		System.out.println("Choose the type of conversion ");
		int choice;
		choice=sc.nextInt();
		float celcius,fahrenheit;
		switch(choice) {
		case 1:
		System.out.println("Enter the Celcius value");
		celcius=sc.nextFloat();
		fahrenheit= celcius*9/5+32;
		System.out.println("Temperature in fahrenheit is "+fahrenheit);
		break;
		case 2:
			System.out.println("Enter the fahrenheit value");
			fahrenheit=sc.nextFloat();
		    celcius=(fahrenheit-32)*5/9;
		System.out.println("Temperature in celcius is "+celcius);
		break;
		default:
			System.out.println("invalid input");
	}

	}
	}

		
		
		
	
