package akash.com;

import java.util.Scanner;

public class SimpleIntrest {
public static void main(String[] args) {
	float p,t,r;
	Scanner sc= new Scanner(System.in);
	System.out.println("enter the principal amount");
	p= sc.nextFloat();
	System.out.println("enter the year");
	t= sc.nextFloat();
	System.out.println("enter the rate of intrest");
	r= sc.nextFloat();
 float si = (p*t*r)/100;
System.out.println("calculate the simple intrest "+si);
	
	}
}

