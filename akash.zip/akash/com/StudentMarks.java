package akash.com;

import java.util.Scanner;

public class StudentMarks {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		char A,B,C,D,Ch,F; 		
		System.out.println("Enter the Grade"); 	
		Ch=sc.next().charAt(0);	 	
		if(Ch=='A') 		{ 		
			System.out.println("Marks Obtained is Between 85 to 100"); 	
			} 		
		else if(Ch=='B') 		
		{ 			
			System.out.println("Marks obtained is between 70 to 85"); 	
			} 		
		else if(Ch=='C') 	
		{ 			
			System.out.println("Marks Obtained is Between 55 to 70"); 
			} 	
		else if(Ch=='D') 	
		{ 			
			System.out.println("Marks Obtained is Between 35 to 55"); 	
			} 		
		else if(Ch=='F') 	
		{ 		
			System.out.println("Marks Obtained is Between 0 to 35"); 	
			} 		 	
		else { 		
			System.out.println("Invalid"); 	
			} 	
		} 
	}
	