package akash.com;

import java.util.Scanner;

public class EvenorOdd {

	public static void main(String[] args) {
		int num; 	
		Scanner sc = new Scanner(System.in); 	
		    System.out.println("Enter the number"); 	
		num=sc.nextInt(); 		
		if(num==0) { 		
			System.out.println("Neither even nor odd"); 		
			} 		
		else if(num%2==0) { 
			System.out.println(num+" is an Even number"); 
			} 		
		else { 		
			System.out.println(num+" is an odd number"); 	
			} 
		} 

		}