package akash.com;

import java.util.Scanner;

public class BubbleSortedMethod {

	public static void main(String[] args) {
		int a[],temp,i,j,n;
		Scanner sc= new Scanner(System.in);
		System.out.println("enter the Size of Arrays");
		n=sc.nextInt();
		a=new int[n];
		 System.out.println("Enter the Array Elements");
		 for(i=0;i<a.length;i++) {
			 a[i]=sc.nextInt();
		 }
		 System.out.println("Before Sorting the Array Elements");
		 for(i=0;i<a.length;i++) {
			 System.out.println(a[i]);
		 }
		 for(i=0;i<a.length-1;i++) {
			 for(j=0;j<a.length-1;j++) {
				 if(a[j]>a[j+1]) {
					 temp=a[j];
					 a[j]=a[j+1];
					 a[j+1]=temp;
				 }
			 }
		 }
		 System.out.println("Sorted Elements Are");
		 for(i=0;i<a.length;i++) {
			 System.out.println(a[i]);
		 }

	}

}
