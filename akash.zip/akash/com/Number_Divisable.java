package akash.com;

import java.util.Scanner;

public class Number_Divisable {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in); 	
		System.out.println("Enter value"); 	
		int n; 		
		n=sc.nextInt(); 	
		if(n%5==0 && n%3==0)  		
		{ 		
			System.out.println("Number is divisible by 5 and 3"); 	
			} 		
		else if(n%5==0) 		
		{ 		
			System.out.println("Number is divisible by 5" ); 	
			} 	
		else if(n%3==0)  	
		{ 		
			System.out.println("Number is divisible by 3" ); 
			} 	
		else 	
		{ 		
			System.out.println("Not Divisible by both number"); 	
			} 
		} 
	}