package akash.com;

import java.util.Scanner;

public class ReversingTheNumbers {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int num, digit, rev=0;
		System.out.println("Enter the Number");
		num=input.nextInt();
		while(num!=0) {
			digit=num%10;
			rev=rev*10+digit;
			// System.out.println("+digit");
			num=num/10;
			
			
		}
		System.out.println("reversed num id "+rev);

	}

}
