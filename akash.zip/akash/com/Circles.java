package akash.com;

public class Circles {

	public static void main(String[] args) 
	{
		double pi,r,circle;
		pi = 3.142;
		r = 6;
		circle = pi*r*r;
		System.out.println("the area of circle "+pi+" and raidus "+r+" is "+circle);

	}

}
