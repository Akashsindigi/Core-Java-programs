package akash.com;

import java.util.Scanner;

public class AverageMarks {

	public static void main(String[] args) {
	Float M,S,SS,E,K,H,Average;
	Scanner sc= new Scanner(System.in);
	System.out.println("first subject marks");
	M = sc.nextFloat();
	System.out.println("second subject marks");
	S = sc.nextFloat();
	System.out.println("Third subject marks");
	SS = sc.nextFloat();
	System.out.println("fourth subject marks");
	E = sc.nextFloat();
	System.out.println("Fifth subject marks");
	K = sc.nextFloat();
	System.out.println("Sixth subject marks");
	H = sc.nextFloat();
	Average = (M+S+SS+E+K+H)/6;
	System.out.println("Average value is "+Average);
	}
}
