package akash.com;

import java.util.Scanner;

public class RateOfDiscount {

	public static void main(String[] args) {
		float amount,discount,rate; 
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the rate of the Product"); 	
		rate=sc.nextFloat(); 	
		if(rate>=1000 && rate<=2000) 	
		{ 		
			discount=(rate*2)/100; 	
			} 		 		
		else if(rate>=2001 && rate<=4000) 	
		{ 		
			discount=(rate*3)/100; 	
			} 		
		else if(rate>=4001 && rate<=6000)  	
		{ 		
			discount=(rate*4)/100; 	
			} 	
		else  	
		{ 			
			discount=(rate*6)/100; 	
			} 		
		System.out.println("Discount amount " +discount); 
		amount=rate-discount; 	
		System.out.println("Net amount to pay for the product " +amount); 	
		} 
	}
