package akash.com;

import java.util.Scanner;

public class UserArrays {

	public static void main(String[] args) {
		int a[]=new int[10];
		int i;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Array Elements");
		for (i=0;i<a.length;i++) {
			a[i]=sc.nextInt();
		}
		System.out.println("Array Elements Are");
		for (i=0;i<a.length;i++) {
			System.out.println(a[i]);
		}
	}

}
