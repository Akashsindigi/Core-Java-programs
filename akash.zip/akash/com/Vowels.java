package akash.com;

import java.util.Scanner;

public class Vowels {

	public static void main(String[] args) {
		char ch; 
		Scanner sc = new Scanner(System.in); 	
		System.out.println("Enter a character"); 
		ch = sc.next().charAt(0); 
		switch(ch) { 	
		case 'A': 
		           	
		case 'E': 
		         	
		case 'I': 
		          	
		case 'O':   
		         	
		case 'U': System.out.println("Vowel"); 		
		          break; 		
		case 'a':   
		           	
		case 'e':       
		         		
		case 'i':   
		          		
		case 'o':   
		         	
		case 'u': System.out.println("Small Alphabets");
		          break; 		  	
		default: 			 
			System.out.println("Not an vowel"); 		          
			} 

	}

}
