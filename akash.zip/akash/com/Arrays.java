package akash.com;

public class Arrays {

	public static void main(String[] args) {
		int a[]= {1,2,3,4,5};
		System.out.println("First element ="+a[0]);
		System.out.println("Second element ="+a[1]);
		System.out.println("Third element ="+a[2]);
		System.out.println("Fourth element ="+a[3]);
		System.out.println("Fifth element ="+a[4]);
	}

}
