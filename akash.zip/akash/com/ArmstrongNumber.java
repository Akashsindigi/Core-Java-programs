package akash.com;

import java.util.Scanner;

public class ArmstrongNumber {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int sum=0, num, num1, digit, rev=0;
		System.out.println("Enter the Number");
		num=input.nextInt();
		num1=num;
		while(num!=0) {
			digit=num%10;
			sum=sum+digit*digit*digit;
			num=num/10;
			}
		if(sum==num1) {
			System.out.println("armstrong number");
		}
		else {
			System.out.println("not armstrong number");
		}

	}

}