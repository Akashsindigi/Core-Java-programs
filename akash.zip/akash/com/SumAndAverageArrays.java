package akash.com;

import java.util.Scanner;

public class SumAndAverageArrays {

	public static void main(String[] args) {
    int a[]=new int [5],i, sum=0; 
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter the Elements");
    for (i=0;i<a.length;i++) {
    	 a[i]=sc.nextInt();	
    }
    System.out.println("Entered Array Elements are");
    for (i=0;i<a.length;i++) {
    	System.out.println(a[i]);
    }
    System.out.println("Sum Of All Array Elements are");
    for (i=0;i<a.length;i++) {
    	sum=sum+a[i];
    }
    System.out.println("sum= "+sum);	
	}
}
