package akash.com;

public class Unarry {

	public static void main(String[] args) 
	{
int no=1;
	for(int i=10;i>=no;i--)
	{
		if(i%2==0)
		{
		System.out.println(i);
	}
	
	}
	}
			
	
} 