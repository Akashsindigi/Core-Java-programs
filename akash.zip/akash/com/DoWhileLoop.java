package akash.com;

import java.util.Scanner;

public class DoWhileLoop {

	public static void main(String[] args) {
		int firstnum,secondnum,ans,choice; 
		char ch;
		Scanner sc=new Scanner(System.in); 
		do {
		System.out.println("Enter firstnumber"); 	
		firstnum=sc.nextInt(); 	
		System.out.println("Enter secondnumber"); 	
		secondnum=sc.nextInt(); 		 	
		System.out.println("**********MENU************"); 	
		System.out.println("1.Addition"); 	
		System.out.println("2.Subtraction"); 
		System.out.println("3.Division");
		System.out.println("4.Modulas");
		System.out.println("5.Multiplication");
		System.out.println("please Enter your choice"); 
		choice=sc.nextInt(); 		 		
		switch(choice) { 	
		case 1: ans=firstnum+secondnum; 		
		System.out.println("addition of "+firstnum+" and "+secondnum+" is "+ans); 
		break; 		
		case 2:ans=firstnum-secondnum;  
		System.out.println("difference of "+firstnum+" and "+secondnum+" is "+ans);  
		break;  
		case 3:ans=firstnum/secondnum; 
		if(ans!=0) {
			ans=firstnum/secondnum;
		System.out.println("Division of "+firstnum+" and "+secondnum+" is "+ans);	
		}
		else {
			System.out.println("not divisiable by zero");
		}
		break;  
		case 4:ans=firstnum%secondnum;  
		System.out.println("Modulas of "+firstnum+" and "+secondnum+" is "+ans);  
		break; 
		case 5:ans=firstnum*secondnum;  
		System.out.println("Multiplication of "+firstnum+" and "+secondnum+" is "+ans);  
		break;
		default:
			System.out.println("invalid input");
		}
		float circle,triangle,r,h,b;
		int choices;
		System.out.println("///////////////////menu/////////////////////");
		System.out.println("6.Area of circle");
		System.out.println("7.Area of triangle");
		System.out.println("please Enter the choices");
		choices=sc.nextInt();
		switch(choices) {
		case 6: 
		System.out.println("enter the radius of the circle");
		r=sc.nextFloat();
		circle=3.142f*r*r;
		System.out.println("find Area of circle "+circle);
		break;
		case 7:  
		System.out.println("enter the height of the triangle");
		h=sc.nextFloat();
		System.out.println("enter the base of the triangle");
		b=sc.nextFloat();
		triangle=(h*b)/2;
		System.out.println("find Area of triangle "+triangle);
		break;

		default:System.out.println("Invalid input"); 	
		} 	
		System.out.println("Do you want to continiue Y/N");
		ch=sc.next().charAt(0);
		}
		while(ch!='N');
		System.out.println("End");
		}
	}

