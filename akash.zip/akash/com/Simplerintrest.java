package akash.com;

public class Simplerintrest {

	public static void main(String[] args) {
	float p,t,r,si;
	p = 6000;
	t = 6;
	r = 8;
	si=(p*t*r)/100;
	System.out.println("simple intrest of principal amount "+p+" for years of "+t+" at the rate of "+r+" is rs "+si);
	}

}
