package akash.com;

public class LoopingGreaterToSmaller {

	public static void main(String[] args) {
	
		int i;
		i=100;
		while(i>=1) {
          System.out.println(i);
           i=i-1;
		}
	}

}
