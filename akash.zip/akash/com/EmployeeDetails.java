package akash.com;

import java.util.Scanner;

public class EmployeeDetails {

	public static void main(String[] args) {
	String Name,Designation;
	int age;
	Float Salary;
	char Gender;
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter the Employee Name");
	Name=sc.nextLine();
	System.out.println("Enter the Employee age");
	age=sc.nextInt();
	System.out.println("Enter the Employee Designation");
	Designation=sc.next();
	System.out.println("Enter the Employee Salary");
	Salary=sc.nextFloat();
	System.out.println("Enter the Employee Gender");
	Gender=sc.next().charAt(0);
	System.out.println("Employee details");
	System.out.println("Name= "+Name);
	System.out.println("age= "+age);
	System.out.println("Designation= "+Designation);
	System.out.println("Salary= "+Salary);
	System.out.println("Gender= "+Gender);
	}

}
