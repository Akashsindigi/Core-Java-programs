package akash.com;

import java.util.Scanner;

public class User_Cridentials {

	public static void main(String[] args) {
	    String user_name,user_password;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your name :");
	    user_name=sc.nextLine();
	    System.out.println("Enter The Password:");
	    user_password=sc.next();
		if(user_name.equalsIgnoreCase("akash sindigi") && user_password.equals("akash@12345")) {
			System.out.println("Login Sucessfull");
		}
		else {
			System.out.println("Invalid User");
		}
		
		

	}

}