package akash.com;

public class Calculation {

	public static void main(String[] args) {
	//si = (p*t*r)/100
		float p,t,r,si;
		p = 3800;
		t = 2;
		r = 8;
		si = (p*t*r)/100;
		System.out.println("simple intrest of principal amount "+p+" for years "+t+" at the rate of intrest "+r+" is "+si);
	
	} 
}
