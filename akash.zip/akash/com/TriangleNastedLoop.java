package akash.com;

public class TriangleNastedLoop {

	public static void main(String[] args) {
		int i,j;
		outer :
		for(i=1;i<=5;i++) {
			inner:
			for(j=1;j<=5;j++) {
				if(i==2 ) {
				System.out.print("i= "+ "j= "+j);
			}
			System.out.println();
		}

	}
	}
}
