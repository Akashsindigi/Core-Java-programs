package akash.com;

import java.util.Scanner;

public class String_word_Count {

	public static void main(String[] args) {
		String s;
		int w=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter String");
		s = sc.nextLine();
		String s1=s.toLowerCase();
				
		System.out.println("No of characters ="+s.length());
		
		for(int i=0;i<s1.length();i++) {
			char ch=s1.charAt(i);
			if(ch==' ') {
				w=w+1;
			}
		}
		System.out.println("No of Words= "+(w+1));		
		}

}