package akash.com;

import java.util.Scanner;

public class Data {

	public static void main(String[] args) {
Scanner input = new Scanner(System .in);
String name;
int age;
float fee;
char gen;
System.out.println("enter your name");
name=input.nextLine();
System.out.println("enter your age");
age=input.nextInt();
System.out.println("enter your fee");
fee=input.nextFloat();
System.out.println("enter your gen");
gen=input.next().charAt(0);

System.out.println("String name= "+name);
System.out.println("int age= "+age);
System.out.println("float= "+fee);
System.out.println("char= "+gen);
	}

}
