package akash.com;

import java.util.Scanner;

public class SumOfNumber {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int sum=0, num,digit;
		System.out.println("Enter the Number");
		num=input.nextInt();
		
		while(num!=0) {
			digit=num%10;
			sum= sum+digit;
			num=num/10;
			}
		System.out.println("the sum of value is "+sum);

	}

}