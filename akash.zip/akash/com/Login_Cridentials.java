package akash.com;

import java.util.Scanner;

public class Login_Cridentials {

	public static void main(String[] args) {
	    String user_name,user_password;
	    int i;
	    System.out.println("you have maximum 3 attempts to login");
	    System.out.println("your account will be locked");
	    System.out.println("You can Try After 24hrs");
		Scanner sc=new Scanner(System.in);
		for(i=1;i<=3;i++) {
		System.out.println("Enter your name :");
	    user_name=sc.nextLine();
	    System.out.println("Enter The Password:");
	    user_password=sc.next();
		if (user_name.equalsIgnoreCase("akash sindigi") && user_password.equals("akash@12345")) {
			System.out.println("Login Sucessfull");
			break ;
		}
		else{
			System.out.println("Invalid User name or Password");
			System.out.println(i+" Attempts are Over");
		}	
		}
		if(i==4) {
		System.out.println("Sorry your Account has been locked try again after 24hrs");
		
		}

	}
}
