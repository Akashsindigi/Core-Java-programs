package akash.com;

import java.util.Scanner;

public class CircleScanner {

	public static void main(String[] args) {
	float pi,r,cir;
	Scanner sc= new Scanner(System.in);
	System.out.println("enter the value of pi");
	pi = sc.nextFloat();
	System.out.println("enter the value of r");
	r = sc.nextFloat();
	cir = pi*r*r;
	System.out.println("calculate the value of circle "+cir);
	
	
	}

}
