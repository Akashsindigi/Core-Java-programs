package akash.com;

import java.util.Scanner;

public class NeonNumber {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int sum=0, num,square, digit;
		System.out.println("Enter the Number");
		num=input.nextInt();
		square = num*num;
		while(square!=0) {
			digit=square%10;
			sum=sum+digit;
			square=square/10;
			}
		if(sum==num) {
			System.out.println("Neon Number");
		}
		else {
			System.out.println("not a Neon Number");
		}

	}

}