package akash.com;

import java.util.Scanner;

public class Forloop {

	public static void main(String[] args) {
		int i,num,factorial=1;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the value if the Number");
		num=sc.nextInt();
	
for(i=num;i>=1;i--) 
{
factorial=factorial*i;

	}
System.out.println("Factorial of given num is "+factorial);
}
}
