package akash.com;

public class Looping {

	public static void main(String[] args) {
		int i;
		i=1;
		while(i<=20) {
		System.out.println(" hi AKASH");
	i=i+1;
		}

	}

}
