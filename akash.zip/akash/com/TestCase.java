package akash.com;

import java.util.Scanner;

public class TestCase {

	public static void main(String[] args) {
		int i,num,count=0,factorial=1;
		Scanner input= new Scanner(System.in);
		System.out.println("enter the num :");
		num= input.nextInt();
		for(i=1;i<=num;i++) {
			if(num%i==0) {
				count=count+1;
				System.out.println(i);
			}
		}
	if(count==2) {
		System.out.println(num+"is prime number");
	}
	else {
		System.out.println(num+" not a prime number");
	}
	}
			
	}

