package akash.com;

import java.util.Scanner;

public class CaseOfVowels {

	public static void main(String[] args) {
		char ch; 
		Scanner sc = new Scanner(System.in); 	
		System.out.println("Enter a character"); 
		ch = sc.next().charAt(0); 
		switch(ch) { 	
		case 'A': System.out.println("Vowel");  
		          break; 	
		case 'E': System.out.println("Vowel");  
		          break; 	
		case 'I': System.out.println("Vowel");  
		          break; 	
		case 'O': System.out.println("Vowel");  
		          break; 	
		case 'U': System.out.println("Vowel"); 		
		          break; 		
		case 'a': System.out.println("Small Alphabets");     
		          break; 	
		case 'e': System.out.println("Small Alphabets");      
		          break; 		
		case 'i': System.out.println("Small Alphabets");  
		          break; 		
		case 'o': System.out.println("Small Alphabets");  
		          break; 	
		case 'u': System.out.println("Small Alphabets");
		          break; 		  	
		default: 			 
			System.out.println("Not an vowel"); 		          
			} 
		}  
	}




