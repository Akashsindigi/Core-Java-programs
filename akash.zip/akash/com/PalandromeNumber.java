package akash.com;

import java.util.Scanner;

public class PalandromeNumber {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int num, digit, rev=0;
		System.out.println("Enter the Number");
		num=input.nextInt();
		int num1=num;
		while(num!=0) {
			digit=num%10;
			rev=rev*10+digit;
			num1=num/10;	
		}
		System.out.println("reversed num id "+rev);
if (rev==num1) {
	System.out.println("palandrome");
}
else {
	System.out.println("not palandrome");
}
	}

}
