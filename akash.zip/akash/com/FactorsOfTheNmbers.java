package akash.com;

import java.util.Scanner;

public class FactorsOfTheNmbers {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int num, i,count=0;
		System.out.println("Enter the Number");
		num=input.nextInt();
		System.out.println("fFactors of the "+num+ " is");
		for (i=1; i<=num; i++) {
			if(num%i==0) {
				count=count+1;
				System.out.println(i);
			}	
		}
		System.out.println(count);
	}

}
